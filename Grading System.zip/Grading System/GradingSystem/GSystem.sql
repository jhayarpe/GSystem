CREATE DATABASE GSystem

use GSystem


CREATE TABLE UserAccount
(
	userId int IDENTITY(1,1) primary key,
	userName varchar (50) not null,
	userPassword varchar (50) not null,
	UserType varchar(20) not null
)
CREATE TABLE Students
(
	StudentID INT PRIMARY KEY,
    UserID INT,
    FullName VARCHAR(100) NOT NULL,
    StudentCourse VARCHAR(50) NOT NULL,
    Email VARCHAR(50) NOT NULL,
    StudentYear INT,
    PhoneNo INT,
    [Address] VARCHAR(255)
)

CREATE TABLE Teacher
(
	TeacherID INT PRIMARY KEY,
    UserID INT,
    FullName VARCHAR(100) NOT NULL,
    [Subject] VARCHAR(50) NOT NULL
)

CREATE TABLE Grade
(
	GradeID INT PRIMARY KEY,
    StudentID INT,
    TeacherID INT,
    Prelim DECIMAL(5, 2),
    Midterm DECIMAL(5, 2),
    SemiFinal DECIMAL(5, 2),
    Final DECIMAL(5, 2)
)

-----------------------------------------PROCEDURE-----------------------------------------------------------------------------

CREATE PROCEDURE USERS
	@userName varchar (50),
	@userPassword varchar (50),
	@UserType Varchar(50)
AS
INSERT INTO UserAccount(userName, userPassword, UserType)
			VALUES(@userName, @userPassword, @UserType)


-----------------------------------------VIEWED-----------------------------------------------------------------------------

CREATE VIEW ViewGrade AS
SELECT
    G.StudentID,
    S.FullName AS StudentName,
    S.StudentCourse,
    S.StudentYear,
    G.TeacherID,
    G.Prelim,
    G.Midterm,
    G.SemiFinal,
    G.Final
FROM
    Grade G
INNER JOIN
    Students S ON G.StudentID = S.StudentID;


----------------------------------------------------------------------------------------------------------------------
ALTER TABLE Students
ALTER COLUMN PhoneNo varchar (20)


alter table UserAccount
alter column PhoneNo varchar(20)



drop VIEW ViewGrade
select * from Grade
DELETE FROM Students where StudentYear =
exec InsertStudent