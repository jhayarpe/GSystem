﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GRADINGSYSTEMS.Forms
{
    public partial class Frm_GradeMaster_Dashboard : Form
    {
        private SqlConnection conn;
        public Frm_GradeMaster_Dashboard()
        {
            InitializeComponent();
            conn = new SqlConnection("Data Source=GaleGrae\\SQLEXPRESS;Initial Catalog=GSystem;Integrated Security=True");
        }

        public void loadView()
        {
            
        }

        private void Frm_GradeMaster_Dashboard_Load(object sender, EventArgs e)
        {
            loadView();
        }

        private void btnInsertGrade_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlCommand com = new SqlCommand("", conn))
                {
                    conn.Open();
                    com.CommandType = CommandType.StoredProcedure;

                    com.Parameters.AddWithValue("@userId", txtId.Text);
                    com.Parameters.AddWithValue("@Name", txtName.Text);
                    com.Parameters.AddWithValue("@Prelim", txtPrelim.Text);
                    com.Parameters.AddWithValue("@Midterm", txtMidterm.Text);
                    com.Parameters.AddWithValue("@Semi_Final", txtSemiFinal.Text);
                    com.Parameters.AddWithValue("@Final", txtFinals.Text);

                    com.ExecuteNonQuery();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally { conn.Close(); }
        }
    }
}
