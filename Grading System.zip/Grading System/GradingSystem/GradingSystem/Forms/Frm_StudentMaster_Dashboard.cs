﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GRADINGSYSTEMS.Forms
{
    public partial class Frm_StudentMaster_Dashboard : Form
    {
        private SqlConnection conn;
        public Frm_StudentMaster_Dashboard()
        {
            InitializeComponent();
            conn = new SqlConnection("Data Source=GaleGrae\\SQLEXPRESS;Initial Catalog=GSystem;Integrated Security=True");
        }

        private void LoadUserAccounts()
        {
            try
            {
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }

                SqlCommand cmd = new SqlCommand("SELECT * FROM Course", conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvCourse.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }

        private void btnInsertInformation_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlCommand com = new SqlCommand("InsertCourse", conn))
                {
                    conn.Open();
                    com.CommandType = CommandType.StoredProcedure;

                    com.Parameters.AddWithValue("@EDP_Code", txtEDP.Text);
                    com.Parameters.AddWithValue("@subject", cbList.SelectedItem);
                    com.Parameters.AddWithValue("@type", txtType.Text);
                    com.Parameters.AddWithValue("@units", txtUnits.Text);
                    com.Parameters.AddWithValue("@days", txtDays.Text);
                    com.Parameters.AddWithValue("@time", txtTime.Text);
                    com.Parameters.AddWithValue("@room", txtRoom.Text);
                    com.Parameters.AddWithValue("@course", txtProgram.Text);

                    com.ExecuteNonQuery();

                }
                LoadUserAccounts();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally { conn.Close(); }
        }

        private void Frm_StudentMaster_Dashboard_Load(object sender, EventArgs e)
        {
            try
            {
                

                SqlDataAdapter da = new SqlDataAdapter("Select * from", conn);
                dgvCourse.DataSource = new DataTable();
                DataSet dset = new DataSet();
                da.Fill(dset, "Course");
                dgvCourse.DataSource = dset.Tables["Course"].DefaultView;

                cbList.Items.Clear();
                cbList.Items.Add("IT-IMDBYSYS31");
                cbList.Items.Add("CC-HCI31");
                cbList.Items.Add("CC-RESCOM31");
                cbList.Items.Add("IT-ELEC 1");
                cbList.Items.Add("IT-FREE EL 2");
                cbList.Items.Add("IT-FREE EL 1");
                cbList.Items.Add("IT-TESQUA31");

                LoadUserAccounts();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally { conn.Close(); }
        }
    }
}
