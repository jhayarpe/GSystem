﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GRADINGSYSTEMS.Forms
{
    public partial class Frm_Student_Dashboard : Form
    {
        
        public Frm_Student_Dashboard()
        {
            InitializeComponent();
        }

        private void Frm_Student_Dashboard_Load(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection("Data Source=GaleGrae\\SQLEXPRESS;Initial Catalog=GSystem;Integrated Security=True");
            string selectQuery = "SELECT * FROM ViewGrade";
            SqlDataAdapter da = new SqlDataAdapter(selectQuery, con);
            DataTable dataTable = new DataTable();
            da.Fill(dataTable);
            dgvStudent.DataSource = dataTable;

        }
    }
}
