﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GRADINGSYSTEMS.Forms
{
    public partial class Frm_Admin_Dashboard : Form
    {
       
        private SqlConnection conn;
        public Frm_Admin_Dashboard()
        {
            InitializeComponent();
            conn = new SqlConnection("Data Source=GaleGrae\\SQLEXPRESS;Initial Catalog=GSystem;Integrated Security=True");
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void loadusers()
        {
            using (SqlConnection con = new SqlConnection("Data Source=GaleGrae\\SQLEXPRESS;Initial Catalog=GSystem;Integrated Security=True"))
            {
                con.Open();
                SqlCommand com = new SqlCommand("SELECT * FROM UserAccount", con);
                SqlDataAdapter adap = new SqlDataAdapter(com);
                DataTable tab = new DataTable();
                adap.Fill(tab);
                dgvAdmin.DataSource = tab;
            }
        }


        private void Frm_Admin_Dashboard_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=GaleGrae\\SQLEXPRESS;Initial Catalog=GSystem;Integrated Security=True");
                string selectQuery ="SELECT * FROM UserAccount";
                SqlDataAdapter da = new SqlDataAdapter(selectQuery, con);
                DataTable dataTable = new DataTable();
                da.Fill(dataTable);
                dgvAdmin.DataSource = dataTable;

                cbType.Items.Clear();
                cbType.Items.Add("Student");
                cbType.Items.Add("Teacher");
                cbType.Items.Add("Admin");


            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally { conn.Close(); }
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlCommand com = new SqlCommand("USERS", conn))
                {
                    conn.Open();
                    com.CommandType = CommandType.StoredProcedure;

                    com.Parameters.AddWithValue("@userName", txtUsername.Text);
                    com.Parameters.AddWithValue("@userPassword", txtPassword.Text);
                    com.Parameters.AddWithValue("@UserType", cbType.SelectedItem.ToString());
                    com.ExecuteNonQuery();

                }
                loadusers();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
            }
            finally { conn.Close(); }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure you want to remove selected rows?", "Confirm Remove", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            { 
                using (SqlConnection con = new SqlConnection("Data Source=GaleGrae\\SQLEXPRESS;Initial Catalog=GSystem;Integrated Security=True"))
                {
                    con.Open();
                    DataGridViewSelectedRowCollection selectedRows = dgvAdmin.SelectedRows;

                    foreach (DataGridViewRow row in selectedRows)
                    {                        string username = row.Cells["userName"].Value.ToString();
                        string password = row.Cells["userPassword"].Value.ToString();
                        string type = row.Cells["UserType"].Value.ToString();

                        SqlCommand com = new SqlCommand("DELETE FROM [UserAccount] WHERE [userName] = @username and [userPassword] = @userpass", con);
                    
                        com.Parameters.AddWithValue("username", username);
                        com.Parameters.AddWithValue("userpass", password);
                        com.Parameters.AddWithValue("type", type);

                        com.ExecuteNonQuery();
                    }

                    loadusers();
                }

                MessageBox.Show("Selected rows removed successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
               
                txtUsername.Clear();
                txtPassword.Clear();
            }

        }

        private void label11_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
           
        }
    }
}
