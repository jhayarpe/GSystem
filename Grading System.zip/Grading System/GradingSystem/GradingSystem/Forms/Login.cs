﻿using GradingSystem.AppData;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Cache;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GRADINGSYSTEMS.Forms
{
    public partial class Login : Form
    {
        private SqlConnection conn;
        public Login()
        {
            InitializeComponent();
            conn = new SqlConnection("Data Source=GaleGrae\\SQLEXPRESS;Initial Catalog=GSystem;Integrated Security=True");
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "")
            {
                MessageBox.Show("Enter the username", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txtPassword.Text == "")
            {
                MessageBox.Show("Enter the password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                { 
                    SqlCommand cmd = new SqlCommand("select * from UserAccount where userName = @username and userPassword = @password", conn);
                    cmd.Parameters.AddWithValue("username", txtUsername.Text);
                    cmd.Parameters.AddWithValue("password", txtPassword.Text);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    da.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        string userType = dt.Rows[0]["UserType"].ToString();

                        if (userType.Equals("Teacher", StringComparison.OrdinalIgnoreCase))
                        {
                            var teacherDashboard = new Frm_Teacher_Dashboard();
                            teacherDashboard.ShowDialog();
                        }
                        else if (userType.Equals("Student", StringComparison.OrdinalIgnoreCase))
                        {
                            var studentDashboard = new Frm_Student_Dashboard();
                            studentDashboard.ShowDialog();
                        }
                        else if (userType.Equals("Admin", StringComparison.OrdinalIgnoreCase))
                        {
                            var adminDashboard = new Frm_Admin_Dashboard();
                            adminDashboard.ShowDialog();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password");
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Please connect to database","Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            txtPassword.Clear();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnLogIn.PerformClick();
            }
        }

        private void txtUsername_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            { 
                btnLogIn.PerformClick();
            }
        }
    }
}
