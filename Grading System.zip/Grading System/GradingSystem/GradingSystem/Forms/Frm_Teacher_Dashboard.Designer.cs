﻿namespace GRADINGSYSTEMS.Forms
{
    partial class Frm_Teacher_Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.btnGradeMaster = new System.Windows.Forms.Button();
            this.Leftpanel = new System.Windows.Forms.Panel();
            this.Logout = new System.Windows.Forms.Label();
            this.Mainpanel = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.Leftpanel.SuspendLayout();
            this.Mainpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(0, 1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(197, 85);
            this.button1.TabIndex = 31;
            this.button1.Text = "COURSE MASTER";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnGradeMaster
            // 
            this.btnGradeMaster.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnGradeMaster.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGradeMaster.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGradeMaster.Location = new System.Drawing.Point(0, 85);
            this.btnGradeMaster.Name = "btnGradeMaster";
            this.btnGradeMaster.Size = new System.Drawing.Size(197, 84);
            this.btnGradeMaster.TabIndex = 37;
            this.btnGradeMaster.Text = "GRADE MASTER";
            this.btnGradeMaster.UseVisualStyleBackColor = false;
            this.btnGradeMaster.Click += new System.EventHandler(this.btnGradeMaster_Click);
            // 
            // Leftpanel
            // 
            this.Leftpanel.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.Leftpanel.Controls.Add(this.Logout);
            this.Leftpanel.Controls.Add(this.button1);
            this.Leftpanel.Controls.Add(this.btnGradeMaster);
            this.Leftpanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.Leftpanel.Location = new System.Drawing.Point(0, 0);
            this.Leftpanel.Name = "Leftpanel";
            this.Leftpanel.Size = new System.Drawing.Size(197, 636);
            this.Leftpanel.TabIndex = 38;
            // 
            // Logout
            // 
            this.Logout.AutoSize = true;
            this.Logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Logout.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Logout.Location = new System.Drawing.Point(67, 508);
            this.Logout.Name = "Logout";
            this.Logout.Size = new System.Drawing.Size(54, 18);
            this.Logout.TabIndex = 38;
            this.Logout.Text = "Logout";
            this.Logout.Click += new System.EventHandler(this.Logout_Click);
            // 
            // Mainpanel
            // 
            this.Mainpanel.Controls.Add(this.label2);
            this.Mainpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Mainpanel.Location = new System.Drawing.Point(197, 0);
            this.Mainpanel.Name = "Mainpanel";
            this.Mainpanel.Size = new System.Drawing.Size(1211, 636);
            this.Mainpanel.TabIndex = 39;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(259, 260);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(785, 46);
            this.label2.TabIndex = 35;
            this.label2.Text = "University of Cebu Lapu-lapu and Manduae";
            // 
            // Frm_Teacher_Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1408, 636);
            this.Controls.Add(this.Mainpanel);
            this.Controls.Add(this.Leftpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Frm_Teacher_Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Frm_Teacher_Dashboard";
            this.Load += new System.EventHandler(this.Frm_Teacher_Dashboard_Load);
            this.Leftpanel.ResumeLayout(false);
            this.Leftpanel.PerformLayout();
            this.Mainpanel.ResumeLayout(false);
            this.Mainpanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnGradeMaster;
        private System.Windows.Forms.Panel Leftpanel;
        private System.Windows.Forms.Panel Mainpanel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Logout;
    }
}